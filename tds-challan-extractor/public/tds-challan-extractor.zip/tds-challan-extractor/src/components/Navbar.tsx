import React from 'react';
import {
  FileText,
  FileSpreadsheet,
  GitCompare,
  Folder,
  Sparkles,
  RotateCcw,
  CheckCircle,
  Download,
} from 'lucide-react';
import { SelectedFolderInfo } from '../types/tds';

interface Props {
  activeTab: 'challans' | 'sap' | 'reconciliation';
  setActiveTab: (tab: 'challans' | 'sap' | 'reconciliation') => void;
  challansCount: number;
  sapCount: number;
  hasGaps: boolean;
  selectedFolder: SelectedFolderInfo | null;
  onOpenFolderModal: () => void;
  onLoadFullDemo: () => void;
  onResetAll: () => void;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  challansCount,
  sapCount,
  hasGaps,
  selectedFolder,
  onOpenFolderModal,
  onLoadFullDemo,
  onResetAll,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-md shadow-blue-500/20 text-white">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-bold text-base sm:text-lg tracking-tight text-white">
                  TDS Challan Extractor
                </h1>
                <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  ITNS 281 &amp; SAP
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Receipts Extraction • Custom Folder Save • Financial Gap Reconciliation
              </p>
            </div>
          </div>

          {/* Workflow Tabs */}
          <div className="hidden md:flex items-center space-x-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
            <button
              onClick={() => setActiveTab('challans')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-2 ${
                activeTab === 'challans'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>1. TDS Challans</span>
              {challansCount > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    activeTab === 'challans' ? 'bg-blue-800 text-white' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  {challansCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('sap')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-2 ${
                activeTab === 'sap'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>2. SAP Payments</span>
              {sapCount > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    activeTab === 'sap' ? 'bg-emerald-800 text-white' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  {sapCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('reconciliation')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-2 ${
                activeTab === 'reconciliation'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <GitCompare className="w-3.5 h-3.5" />
              <span>3. Reconciliation</span>
              {hasGaps && (
                <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" title="Gaps detected"></span>
              )}
            </button>
          </div>

          {/* Right Header Utilities */}
          <div className="flex items-center space-x-2.5">
            {/* Folder Picker Indicator */}
            <button
              onClick={onOpenFolderModal}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center space-x-1.5 ${
                selectedFolder
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-600/40 hover:bg-emerald-900/50'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
              title="Select folder for saving Excel files"
            >
              <Folder className="w-3.5 h-3.5 text-blue-400" />
              <span className="max-w-[120px] truncate hidden sm:inline">
                {selectedFolder ? selectedFolder.name : 'Select Folder'}
              </span>
            </button>

            {/* Quick Demo */}
            <button
              onClick={onLoadFullDemo}
              className="px-3 py-1.5 bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 hover:text-white text-xs font-semibold rounded-lg border border-blue-500/40 transition-colors flex items-center space-x-1.5"
              title="Load full demonstration data"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Load Demo</span>
            </button>

            {/* Shareable HTML Tool for Offline/Colleagues */}
            <a
              href="/tds-challan-reconciliation-standalone.html"
              download="TDS_Challan_SAP_Reconciliation_Offline_Tool.html"
              className="px-2.5 py-1.5 text-xs font-semibold text-emerald-300 hover:text-white bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/60 hover:border-emerald-700 rounded-lg transition-colors flex items-center space-x-1.5 shadow-xs"
              title="Download standalone single-file HTML to email or share with others"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Shareable HTML</span>
            </a>

            {/* Reset All Data */}
            {(challansCount > 0 || sapCount > 0) && (
              <button
                onClick={onResetAll}
                className="px-2.5 py-1.5 text-xs font-semibold text-rose-300 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 hover:border-rose-700 rounded-lg transition-colors flex items-center space-x-1.5 shadow-xs"
                title="Reset all extracted challans and SAP records"
              >
                <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">Reset All Data</span>
                <span className="sm:hidden">Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Nav Tabs */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('challans')}
            className={`py-1 px-2.5 rounded font-semibold ${
              activeTab === 'challans' ? 'bg-blue-600 text-white' : 'text-slate-400'
            }`}
          >
            Challans ({challansCount})
          </button>
          <button
            onClick={() => setActiveTab('sap')}
            className={`py-1 px-2.5 rounded font-semibold ${
              activeTab === 'sap' ? 'bg-emerald-600 text-white' : 'text-slate-400'
            }`}
          >
            SAP ({sapCount})
          </button>
          <button
            onClick={() => setActiveTab('reconciliation')}
            className={`py-1 px-2.5 rounded font-semibold ${
              activeTab === 'reconciliation' ? 'bg-indigo-600 text-white' : 'text-slate-400'
            }`}
          >
            Reconciliation
          </button>
        </div>
      </div>
    </header>
  );
};
